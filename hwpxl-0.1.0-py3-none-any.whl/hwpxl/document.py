"""HWP/HWPX/ODT 문서를 본문 흐름 그대로 따라가는 블록 시퀀스로 추출한다.

블록 종류는 두 가지:

- ``Paragraph(text, level)`` — 본문 문단. ``level`` 이 1 이상이면 헤딩.
- ``TableBlock(table)`` — 표 한 개 (``core.tables_hwpx.Table`` 재사용).

추출기는 문서를 위에서 아래로 읽으며 만나는 순서대로 블록을 ``yield`` 한다.
이렇게 모은 시퀀스를 그대로 한 시트에 흘려쓰면 원본 문서의 흐름이 그대로 보존된다.
"""
from __future__ import annotations

import zipfile
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, Iterator

from lxml import etree

from hwpxl.tables_hwpx import HP_NS, Cell, Table


# HWPX 네임스페이스
_HP_P = f"{{{HP_NS}}}p"
_HP_T = f"{{{HP_NS}}}t"
_HP_TBL = f"{{{HP_NS}}}tbl"
_HP_TR = f"{{{HP_NS}}}tr"
_HP_TC = f"{{{HP_NS}}}tc"
_HP_CELL_ADDR = f"{{{HP_NS}}}cellAddr"
_HP_CELL_SPAN = f"{{{HP_NS}}}cellSpan"

# ODT 네임스페이스
ODT_OFFICE = "urn:oasis:names:tc:opendocument:xmlns:office:1.0"
ODT_TEXT = "urn:oasis:names:tc:opendocument:xmlns:text:1.0"
ODT_TABLE = "urn:oasis:names:tc:opendocument:xmlns:table:1.0"

_OFFICE_BODY = f"{{{ODT_OFFICE}}}body"
_OFFICE_TEXT = f"{{{ODT_OFFICE}}}text"
_TEXT_P = f"{{{ODT_TEXT}}}p"
_TEXT_H = f"{{{ODT_TEXT}}}h"
_TEXT_LIST = f"{{{ODT_TEXT}}}list"
_TEXT_LIST_ITEM = f"{{{ODT_TEXT}}}list-item"
_TBL_TABLE = f"{{{ODT_TABLE}}}table"
_TBL_ROW = f"{{{ODT_TABLE}}}table-row"
_TBL_CELL = f"{{{ODT_TABLE}}}table-cell"
_TBL_COVERED = f"{{{ODT_TABLE}}}covered-table-cell"
_TBL_COL_REPEATED = f"{{{ODT_TABLE}}}number-columns-repeated"
_TBL_COL_SPANNED = f"{{{ODT_TABLE}}}number-columns-spanned"
_TBL_ROW_SPANNED = f"{{{ODT_TABLE}}}number-rows-spanned"


@dataclass
class Paragraph:
    text: str
    level: int = 0  # 0=본문, 1~=heading 레벨


@dataclass
class TableBlock:
    table: Table


Block = Paragraph | TableBlock


# ---------------------------------------------------------------------------
# HWPX
# ---------------------------------------------------------------------------

def _hwpx_paragraph_text(p_elem: etree._Element) -> str:
    """``<hp:p>`` 안의 ``<hp:t>`` 텍스트를 모은다 (표 내부는 제외)."""
    parts: list[str] = []
    for t in p_elem.iter(_HP_T):
        # 자기 위의 조상 중에 hp:tbl이 있으면 표 내부이므로 건너뜀
        anc = t.getparent()
        skip = False
        while anc is not None and anc is not p_elem:
            if anc.tag == _HP_TBL:
                skip = True
                break
            anc = anc.getparent()
        if not skip and t.text:
            parts.append(t.text)
    return "".join(parts).strip()


def _hwpx_parse_table(tbl: etree._Element) -> Table:
    rows = int(tbl.get("rowCnt", "0") or 0)
    cols = int(tbl.get("colCnt", "0") or 0)
    table = Table(rows=rows, cols=cols)
    for tr in tbl.findall(_HP_TR):
        for tc in tr.findall(_HP_TC):
            addr = tc.find(_HP_CELL_ADDR)
            span = tc.find(_HP_CELL_SPAN)
            if addr is None:
                continue
            r = int(addr.get("rowAddr", "0") or 0)
            c = int(addr.get("colAddr", "0") or 0)
            rs = int(span.get("rowSpan", "1") or 1) if span is not None else 1
            cs = int(span.get("colSpan", "1") or 1) if span is not None else 1
            # 셀 안의 텍스트는 자체 <hp:p>들의 텍스트를 줄바꿈으로 join
            lines: list[str] = []
            for p in tc.findall(f".//{_HP_P}"):
                line = _hwpx_paragraph_text(p)
                if line:
                    lines.append(line)
            table.cells.append(
                Cell(row=r, col=c, row_span=rs, col_span=cs, text="\n".join(lines))
            )
    return table


def extract_blocks_from_hwpx(path: str | Path) -> list[Block]:
    """HWPX 파일을 블록 시퀀스(문단/표)로 변환한다.

    section root(``<hs:sec>``)의 **직속 자식 paragraph**만 순회하여 본문으로 다루고,
    paragraph 안의 인라인 표(``<hp:tbl>``)는 같은 자리에서 별도 블록으로 추출한다.
    표 안의 셀에도 ``<hp:p>``가 들어 있지만, 직속이 아니므로 본문으로 잡히지 않는다.
    """
    path = Path(path)
    blocks: list[Block] = []
    with zipfile.ZipFile(path) as zf:
        section_names = sorted(
            n for n in zf.namelist()
            if n.startswith("Contents/section") and n.endswith(".xml")
        )
        for name in section_names:
            data = zf.read(name)
            try:
                root = etree.fromstring(data)
            except etree.XMLSyntaxError:
                continue

            # section root 직속 자식 paragraph만 처리. 표 안의 paragraph는
            # 셀 텍스트로 _hwpx_parse_table에서만 사용된다.
            for p in root.findall(_HP_P):
                text = _hwpx_paragraph_text(p)
                if text:
                    blocks.append(Paragraph(text=text))
                # paragraph 안에 인라인으로 들어있는 표를 발견한 순서대로 추가.
                # 중첩 표(셀 안 표)는 외부 표 한 번만 잡도록 한 단계만 본다.
                for tbl in p.iter(_HP_TBL):
                    # tbl 위 조상에 또 다른 tbl이 있으면 중첩이므로 스킵.
                    anc = tbl.getparent()
                    nested = False
                    while anc is not None and anc is not p:
                        if anc.tag == _HP_TBL:
                            nested = True
                            break
                        anc = anc.getparent()
                    if nested:
                        continue
                    blocks.append(TableBlock(_hwpx_parse_table(tbl)))
    return blocks


# ---------------------------------------------------------------------------
# ODT
# ---------------------------------------------------------------------------

def _odt_paragraph_text(elem: etree._Element) -> str:
    return "".join(elem.itertext()).strip()


def _odt_parse_table(tbl: etree._Element) -> Table:
    cells: list[Cell] = []
    row_idx = 0
    max_col = 0
    for tr in tbl.findall(_TBL_ROW):
        col_idx = 0
        for tc in tr:
            tag = etree.QName(tc).localname
            if tag == "covered-table-cell":
                cols_rep = int(tc.get(_TBL_COL_REPEATED, "1") or 1)
                col_idx += cols_rep
                continue
            if tag != "table-cell":
                continue
            cols_spanned = int(tc.get(_TBL_COL_SPANNED, "1") or 1)
            rows_spanned = int(tc.get(_TBL_ROW_SPANNED, "1") or 1)
            cols_repeated = int(tc.get(_TBL_COL_REPEATED, "1") or 1)
            # 셀 안의 문단 텍스트들
            lines = []
            for p in tc.iter():
                if etree.QName(p).localname in ("p", "h"):
                    s = "".join(p.itertext()).strip()
                    if s:
                        lines.append(s)
            text = "\n".join(lines)
            for _ in range(cols_repeated):
                cells.append(Cell(row=row_idx, col=col_idx, row_span=rows_spanned, col_span=cols_spanned, text=text))
                col_idx += cols_spanned
        max_col = max(max_col, col_idx)
        row_idx += 1
    max_row = max((c.row + c.row_span for c in cells), default=0)
    return Table(rows=max_row, cols=max_col, cells=cells)


def _odt_iter_body(office_text: etree._Element) -> Iterator[etree._Element]:
    """``<office:text>`` 직속 자식을 순회. ``<text:list>`` 안의 항목도 평탄화한다."""
    for child in office_text:
        tag = etree.QName(child).localname
        if tag == "list":
            # list 안의 list-item > p/h 들을 flat하게
            for li in child.iter(_TEXT_LIST_ITEM):
                for grand in li:
                    yield grand
        else:
            yield child


def extract_blocks_from_odt(path: str | Path) -> list[Block]:
    path = Path(path)
    with zipfile.ZipFile(path) as zf:
        if "content.xml" not in zf.namelist():
            return []
        data = zf.read("content.xml")
    root = etree.fromstring(data)
    body = root.find(_OFFICE_BODY)
    if body is None:
        return []
    office_text = body.find(_OFFICE_TEXT)
    if office_text is None:
        return []

    blocks: list[Block] = []
    for elem in _odt_iter_body(office_text):
        tag = etree.QName(elem).localname
        if tag == "p":
            t = _odt_paragraph_text(elem)
            if t:
                blocks.append(Paragraph(text=t, level=0))
        elif tag == "h":
            t = _odt_paragraph_text(elem)
            level = int(elem.get(f"{{{ODT_TEXT}}}outline-level", "1") or 1)
            if t:
                blocks.append(Paragraph(text=t, level=level))
        elif tag == "table":
            blocks.append(TableBlock(_odt_parse_table(elem)))
        # 그 외 (sequence-decls, soft-page-break 등)는 무시
    return blocks
