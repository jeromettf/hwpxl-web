"""블록 시퀀스를 HTML로 렌더링한다.

본문 문단은 ``<p>`` 또는 ``<h1>``~``<h6>``, 표는 ``<table>`` 로 변환한다.
셀 병합은 ``rowspan`` / ``colspan`` 으로 그대로 표현되며, 줄바꿈은 ``<br>`` 로 유지된다.

두 가지 엔트리:
- :func:`render_body` — ``<body>`` 안에 들어갈 본문 HTML만 반환
- :func:`render_document` — DOCTYPE + 스타일이 포함된 **독립 실행 HTML 문서** 반환
"""
from __future__ import annotations

from html import escape
from pathlib import Path
from typing import Iterable

from hwpxl.document import Block, Paragraph, TableBlock
from hwpxl.tables_hwpx import Table


DEFAULT_CSS = """\
:root {
  --fg: #1f2433;
  --muted: #6b7280;
  --bg: #ffffff;
  --border: #d6d9e2;
  --accent: #2f5fff;
  --table-header: #f4f5fa;
}
* { box-sizing: border-box; }
html, body { margin: 0; padding: 0; background: var(--bg); color: var(--fg); }
body {
  font-family: -apple-system, BlinkMacSystemFont, "Apple SD Gothic Neo", "Segoe UI",
               "Noto Sans KR", "맑은 고딕", Roboto, sans-serif;
  line-height: 1.55;
  padding: 32px max(24px, calc((100vw - 880px) / 2));
}
.hwpxl-doc h1, .hwpxl-doc h2, .hwpxl-doc h3 {
  margin: 1.4em 0 0.5em;
  letter-spacing: -0.01em;
  line-height: 1.3;
}
.hwpxl-doc h1 { font-size: 1.6rem; }
.hwpxl-doc h2 { font-size: 1.3rem; }
.hwpxl-doc h3 { font-size: 1.1rem; }
.hwpxl-doc p { margin: 0.3em 0; white-space: pre-wrap; }
.hwpxl-doc table {
  border-collapse: collapse;
  margin: 1em 0;
  width: 100%;
  font-size: 0.95rem;
}
.hwpxl-doc th, .hwpxl-doc td {
  border: 1px solid var(--border);
  padding: 6px 10px;
  vertical-align: top;
  text-align: left;
  white-space: pre-wrap;
}
.hwpxl-doc thead th, .hwpxl-doc tr:first-child td {
  background: var(--table-header);
  font-weight: 600;
}
.hwpxl-doc .empty-note {
  color: var(--muted);
  font-style: italic;
}
"""


def _text_to_html(text: str) -> str:
    """텍스트 escape + 줄바꿈을 <br>로 변환."""
    return escape(text, quote=False).replace("\n", "<br>")


def _render_paragraph(p: Paragraph) -> str:
    body = _text_to_html(p.text)
    if p.level <= 0:
        return f"<p>{body}</p>"
    tag = f"h{min(p.level, 6)}"
    return f"<{tag}>{body}</{tag}>"


def _render_table(table: Table) -> str:
    if table.rows <= 0 or table.cols <= 0 or not table.cells:
        return ""
    # 좌표 -> Cell 매핑 + 병합 영역 마킹
    grid: dict[tuple[int, int], object] = {}
    covered: set[tuple[int, int]] = set()
    for cell in table.cells:
        grid[(cell.row, cell.col)] = cell
        for r in range(cell.row, cell.row + cell.row_span):
            for c in range(cell.col, cell.col + cell.col_span):
                if (r, c) != (cell.row, cell.col):
                    covered.add((r, c))

    out = ["<table>"]
    for r in range(table.rows):
        out.append("<tr>")
        for c in range(table.cols):
            if (r, c) in covered:
                continue
            cell = grid.get((r, c))
            if cell is None:
                # 빈 셀
                out.append("<td></td>")
                continue
            attrs = []
            if cell.row_span > 1:
                attrs.append(f'rowspan="{cell.row_span}"')
            if cell.col_span > 1:
                attrs.append(f'colspan="{cell.col_span}"')
            attr_str = (" " + " ".join(attrs)) if attrs else ""
            out.append(f"<td{attr_str}>{_text_to_html(cell.text)}</td>")
        out.append("</tr>")
    out.append("</table>")
    return "".join(out)


def render_body(blocks: Iterable[Block]) -> str:
    """블록 시퀀스를 ``<body>`` 본문 HTML 조각으로 변환한다."""
    parts: list[str] = ['<div class="hwpxl-doc">']
    any_block = False
    for b in blocks:
        any_block = True
        if isinstance(b, Paragraph):
            parts.append(_render_paragraph(b))
        elif isinstance(b, TableBlock):
            parts.append(_render_table(b.table))
    if not any_block:
        parts.append('<p class="empty-note">이 문서에서 추출 가능한 내용이 없습니다.</p>')
    parts.append("</div>")
    return "\n".join(parts)


def render_document(
    blocks: Iterable[Block],
    *,
    title: str = "HWP 뷰어",
    extra_head: str = "",
) -> str:
    """블록 시퀀스를 독립 실행 가능한 HTML 문서로 변환한다."""
    body = render_body(blocks)
    return (
        "<!DOCTYPE html>\n"
        '<html lang="ko">\n'
        "<head>\n"
        '<meta charset="UTF-8">\n'
        f"<title>{escape(title)}</title>\n"
        f"<style>{DEFAULT_CSS}</style>\n"
        f"{extra_head}\n"
        "</head>\n"
        f"<body>\n{body}\n</body>\n</html>\n"
    )


def render_file(path: str | Path, *, title: str | None = None) -> str:
    """파일 경로 하나로 HTML 문서를 만든다 (자동 형식 감지)."""
    from hwpxl import extract_blocks

    blocks = extract_blocks(path)
    return render_document(blocks, title=title or Path(path).stem)
