from __future__ import annotations

from pathlib import Path

from hwpxl.detect import HwpFormat, detect_format
from hwpxl.document import extract_blocks_from_hwpx, extract_blocks_from_odt
from hwpxl.hwp5_reader import extract_blocks_from_hwp
from hwpxl.xlsx_writer import write_document_to_xlsx


class ConversionError(RuntimeError):
    pass


def convert_to_xlsx(input_path: str | Path, output_dir: str | Path, timeout: int = 300) -> Path:
    """HWP/HWPX 파일을 .xlsx로 변환한다 (문서 전체 모드).

    LibreOffice/Java/외부 프로세스에 의존하지 않는 **순수 Python 파이프라인**.

    - HWPX: ``Contents/section*.xml`` 직접 파싱.
    - HWP 5.x: ``olefile`` + 자체 바이너리 레코드 파서(``core.hwp5_reader``).

    본문 문단과 표를 원본 순서대로 한 시트(``문서``)에 흘려쓴다.
    """
    src = Path(input_path).resolve()
    out_dir = Path(output_dir).resolve()
    out_dir.mkdir(parents=True, exist_ok=True)

    if not src.exists():
        raise ConversionError(f"입력 파일이 존재하지 않습니다: {src}")

    fmt = detect_format(src)
    out_path = out_dir / (src.stem + ".xlsx")

    if fmt == HwpFormat.HWPX:
        try:
            blocks = extract_blocks_from_hwpx(src)
        except Exception as e:
            raise ConversionError(f"HWPX 파싱 실패: {e}") from e
    elif fmt == HwpFormat.HWP:
        try:
            blocks = extract_blocks_from_hwp(src)
        except Exception as e:
            raise ConversionError(f"HWP 5.x 파싱 실패: {e}") from e
    elif fmt == HwpFormat.ODT:
        try:
            blocks = extract_blocks_from_odt(src)
        except Exception as e:
            raise ConversionError(f"ODT 파싱 실패: {e}") from e
    elif fmt == HwpFormat.PDF:
        try:
            # 지연 import — pdfminer.six가 설치된 환경에서만 PDF 분기 사용
            from hwpxl.pdf_reader import extract_blocks_from_pdf

            blocks = extract_blocks_from_pdf(src)
        except ImportError as e:
            raise ConversionError(
                "PDF 처리에는 pdfminer.six 가 필요합니다. "
                "pip install pdfminer.six"
            ) from e
        except Exception as e:
            raise ConversionError(f"PDF 파싱 실패: {e}") from e
    else:
        raise ConversionError(
            "지원하지 않는 파일 형식입니다. HWP 5.x(.hwp), HWPX(.hwpx), ODT(.odt), PDF(.pdf)만 지원합니다."
        )

    return write_document_to_xlsx(blocks, out_path)
