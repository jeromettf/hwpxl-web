"""hwpxl — 순수 Python HWP / HWPX → Excel 변환 및 뷰어 툴킷.

LibreOffice·Java 같은 외부 의존성 없이 HWP 5.x(OLE) / HWPX(XML) 문서를
파싱하여 본문과 표를 추출하고, Excel(.xlsx)·HTML 등 다양한 출력으로 변환한다.

공개 API:

>>> from hwpxl import convert_to_xlsx, render_html, extract_blocks
>>> out = convert_to_xlsx("input.hwp", "/tmp")           # → /tmp/input.xlsx
>>> html = render_html(extract_blocks("input.hwp"))     # → str
"""
from __future__ import annotations

__version__ = "0.1.0"

from pathlib import Path

from hwpxl.detect import HwpFormat, detect_format
from hwpxl.document import (
    Block,
    Paragraph,
    TableBlock,
    extract_blocks_from_hwpx,
    extract_blocks_from_odt,
)
from hwpxl.html_renderer import render_body, render_document, render_file
from hwpxl.hwp5_reader import extract_blocks_from_hwp
from hwpxl.ocr_blocks import extract_blocks_from_ocr
from hwpxl.to_xlsx import ConversionError, convert_to_xlsx
from hwpxl.xlsx_writer import write_document_to_xlsx, write_tables_to_xlsx


def extract_blocks(path: str | Path) -> list[Block]:
    """파일 형식을 자동 감지해 본문 블록 시퀀스를 반환한다."""
    fmt = detect_format(path)
    if fmt == HwpFormat.HWP:
        return extract_blocks_from_hwp(path)
    if fmt == HwpFormat.HWPX:
        return extract_blocks_from_hwpx(path)
    if fmt == HwpFormat.ODT:
        return extract_blocks_from_odt(path)
    if fmt == HwpFormat.PDF:
        from hwpxl.pdf_reader import extract_blocks_from_pdf

        return extract_blocks_from_pdf(path)
    raise ConversionError(
        "지원하지 않는 파일 형식입니다. HWP 5.x(.hwp), HWPX(.hwpx), ODT(.odt), PDF(.pdf)만 지원합니다."
    )


__all__ = [
    "__version__",
    "Block",
    "ConversionError",
    "HwpFormat",
    "Paragraph",
    "TableBlock",
    "convert_to_xlsx",
    "detect_format",
    "extract_blocks",
    "extract_blocks_from_hwp",
    "extract_blocks_from_hwpx",
    "extract_blocks_from_odt",
    "extract_blocks_from_ocr",
    "render_body",
    "render_document",
    "render_file",
    "write_document_to_xlsx",
    "write_tables_to_xlsx",
]
