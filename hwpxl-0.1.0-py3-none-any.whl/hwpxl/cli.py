"""hwpxl 명령행 도구.

사용 예::

    hwpxl convert input.hwp                  # 같은 폴더에 input.xlsx 생성
    hwpxl convert input.hwp -o out.xlsx      # 지정 경로로 저장
    hwpxl batch ./folder                      # 폴더 내 모든 hwp/hwpx 변환
    hwpxl batch ./folder --skip-existing     # 이미 변환된 건 건너뜀
    hwpxl view input.hwp                      # HTML 뷰어로 보기 (브라우저 자동 실행)
    hwpxl view input.hwp -o out.html         # HTML 파일만 저장
    hwpxl serve --port 8000                   # 로컬 웹 앱 실행
"""
from __future__ import annotations

import argparse
import sys
import time
import traceback
import webbrowser
from pathlib import Path

from hwpxl import ConversionError, __version__, convert_to_xlsx, render_file


def _add_convert(sub: argparse._SubParsersAction) -> None:
    p = sub.add_parser(
        "convert",
        help="단일 파일을 Excel(.xlsx)로 변환",
        description="HWP/HWPX 파일을 .xlsx로 변환합니다.",
    )
    p.add_argument("input", type=Path, help="입력 .hwp / .hwpx 파일")
    p.add_argument(
        "-o", "--output",
        type=Path,
        help="출력 .xlsx 경로 (기본: 입력 파일과 같은 폴더, 같은 이름)",
    )
    p.set_defaults(func=_cmd_convert)


def _cmd_convert(args: argparse.Namespace) -> int:
    src = args.input.expanduser().resolve()
    if not src.exists():
        print(f"입력 파일이 없습니다: {src}", file=sys.stderr)
        return 2

    if args.output:
        out_path = args.output.expanduser().resolve()
        out_dir = out_path.parent
        # convert_to_xlsx는 stem 기반 출력이라, 출력 stem이 다르면 사후 rename
        produced = convert_to_xlsx(src, out_dir)
        if produced != out_path:
            out_path.parent.mkdir(parents=True, exist_ok=True)
            produced.replace(out_path)
            produced = out_path
    else:
        produced = convert_to_xlsx(src, src.parent)
    print(f"{src.name}  →  {produced}")
    return 0


def _add_batch(sub: argparse._SubParsersAction) -> None:
    p = sub.add_parser(
        "batch",
        help="폴더 내 모든 hwp/hwpx 파일을 변환",
        description="폴더(하위 포함)의 모든 .hwp/.hwpx 파일을 같은 위치에 .xlsx로 변환합니다.",
    )
    p.add_argument("root", type=Path, help="대상 폴더")
    p.add_argument("--skip-existing", action="store_true", help="이미 .xlsx 있으면 건너뜀")
    p.add_argument("--limit", type=int, default=0, help="N개만 처리 (0=전체)")
    p.set_defaults(func=_cmd_batch)


def _cmd_batch(args: argparse.Namespace) -> int:
    root = args.root.expanduser().resolve()
    if not root.exists():
        print(f"폴더가 없습니다: {root}", file=sys.stderr)
        return 2
    inputs = sorted(
        p
        for p in root.rglob("*")
        if p.is_file() and p.suffix.lower() in {".hwp", ".hwpx"}
    )
    if args.limit:
        inputs = inputs[: args.limit]

    print(f"[batch] 대상 {len(inputs)}개 (root={root})", flush=True)
    n_ok = n_skip = n_fail = 0
    t0 = time.monotonic()

    for i, src in enumerate(inputs, start=1):
        out = src.with_suffix(".xlsx")
        rel = src.relative_to(root)
        if args.skip_existing and out.exists():
            n_skip += 1
            print(f"[{i}/{len(inputs)}] SKIP  {rel}", flush=True)
            continue
        try:
            t = time.monotonic()
            result = convert_to_xlsx(src, src.parent)
            elapsed = time.monotonic() - t
            n_ok += 1
            print(
                f"[{i}/{len(inputs)}] OK    {rel}  →  {result.name} "
                f"({result.stat().st_size:,}B, {elapsed:.1f}s)",
                flush=True,
            )
        except ConversionError as e:
            n_fail += 1
            print(f"[{i}/{len(inputs)}] FAIL  {rel}  : {e}", flush=True)
        except Exception as e:
            n_fail += 1
            print(f"[{i}/{len(inputs)}] ERROR {rel}  : {e!r}", flush=True)
            traceback.print_exc()

    total = time.monotonic() - t0
    print(
        f"\n[batch] 완료: 성공 {n_ok} · 건너뜀 {n_skip} · 실패 {n_fail} (총 {total:.1f}s)",
        flush=True,
    )
    return 0 if n_fail == 0 else 1


def _add_view(sub: argparse._SubParsersAction) -> None:
    p = sub.add_parser(
        "view",
        help="HTML 뷰어로 열기",
        description="HWP/HWPX 파일을 HTML로 렌더링하여 기본 브라우저에서 열거나 파일로 저장합니다.",
    )
    p.add_argument("input", type=Path, help="입력 .hwp / .hwpx 파일")
    p.add_argument("-o", "--output", type=Path, help="HTML 파일로만 저장 (브라우저 열지 않음)")
    p.add_argument("--no-open", action="store_true", help="브라우저 자동 실행 비활성화")
    p.set_defaults(func=_cmd_view)


def _cmd_view(args: argparse.Namespace) -> int:
    src = args.input.expanduser().resolve()
    if not src.exists():
        print(f"입력 파일이 없습니다: {src}", file=sys.stderr)
        return 2
    html = render_file(src)

    if args.output:
        out = args.output.expanduser().resolve()
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(html, encoding="utf-8")
        print(f"HTML 저장: {out}")
        if not args.no_open:
            webbrowser.open(out.as_uri())
        return 0

    # 임시 파일에 쓰고 브라우저 자동 실행
    import tempfile

    fd = tempfile.NamedTemporaryFile(
        prefix="hwpxl_view_", suffix=".html", delete=False, mode="w", encoding="utf-8"
    )
    try:
        fd.write(html)
    finally:
        fd.close()
    print(f"임시 HTML: {fd.name}")
    if not args.no_open:
        webbrowser.open(Path(fd.name).as_uri())
    return 0


def _add_serve(sub: argparse._SubParsersAction) -> None:
    p = sub.add_parser(
        "serve",
        help="로컬 웹 앱 실행 (드래그앤드롭 업로드 + 뷰어 + 다운로드)",
        description="FastAPI 기반 로컬 웹 앱을 띄웁니다.",
    )
    p.add_argument("--host", default="127.0.0.1")
    p.add_argument("--port", type=int, default=8000)
    p.add_argument("--no-open", action="store_true", help="브라우저 자동 실행 비활성화")
    p.set_defaults(func=_cmd_serve)


def _cmd_serve(args: argparse.Namespace) -> int:
    try:
        import uvicorn  # type: ignore
    except ModuleNotFoundError:
        print(
            "웹 앱 실행에는 추가 의존성이 필요합니다.\n"
            "  pip install 'hwpxl[web]'  또는  pip install fastapi uvicorn python-multipart jinja2",
            file=sys.stderr,
        )
        return 2

    if not args.no_open:
        # uvicorn 시작 직후 브라우저 열기 (백그라운드 타이머)
        import threading

        def _open() -> None:
            time.sleep(1.0)
            webbrowser.open(f"http://{args.host}:{args.port}")

        threading.Thread(target=_open, daemon=True).start()

    uvicorn.run("hwpxl.web.main:app", host=args.host, port=args.port, log_level="warning")
    return 0


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="hwpxl",
        description="순수 Python HWP/HWPX → Excel 변환 및 뷰어 (LibreOffice/Java 불필요)",
    )
    p.add_argument("--version", action="version", version=f"hwpxl {__version__}")
    sub = p.add_subparsers(dest="command", required=True, metavar="<command>")
    _add_convert(sub)
    _add_batch(sub)
    _add_view(sub)
    _add_serve(sub)
    return p


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        return args.func(args)
    except ConversionError as e:
        print(f"오류: {e}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
