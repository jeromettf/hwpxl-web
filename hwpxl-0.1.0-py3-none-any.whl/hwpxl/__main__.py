"""``python -m hwpxl ...`` 진입점."""
from hwpxl.cli import main

if __name__ == "__main__":
    raise SystemExit(main())
