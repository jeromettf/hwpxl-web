"""HWP 5.x (한글 2007+) 바이너리 직접 리더.

LibreOffice/H2Orestart에 의존하지 않고, 한컴 공개 명세에 따라 OLE Compound File 안의
BodyText 스트림을 직접 파싱하여 본문 문단과 표를 추출한다.

처리 흐름:

1. ``olefile``로 OLE 컨테이너를 열고 ``FileHeader``로 압축 여부를 확인한다.
2. ``BodyText/Section*`` 스트림을 zlib(raw deflate)으로 압축 해제한다.
3. 4-byte 레코드 헤더(tag/level/size)를 따라 모든 레코드를 평면 리스트로 읽는다.
4. ``level`` 기반 트리 구조를 따라가며:
   - level 0 ``PARA_HEADER`` → 본문 문단 시작
   - 그 자식 ``PARA_TEXT`` → 텍스트
   - 그 자식 ``CTRL_HEADER`` 중 ctrlID="tbl " → 표
     · 그 자식 ``TABLE`` 레코드에서 (rowCount, colCount) 추출
     · 그 자식 ``LIST_HEADER`` (각 셀) → col/row/colSpan/rowSpan + 셀 내부 문단들
5. ``document.Paragraph`` 와 ``document.TableBlock`` 시퀀스로 변환한다.
"""
from __future__ import annotations

import struct
import zlib
from dataclasses import dataclass, field
from pathlib import Path

import olefile

from hwpxl.document import Block, Paragraph, TableBlock
from hwpxl.tables_hwpx import Cell, Table


# ---------------------------------------------------------------------------
# 레코드 태그 정의
# ---------------------------------------------------------------------------

HWPTAG_BEGIN = 0x010
HWPTAG_PARA_HEADER = HWPTAG_BEGIN + 50  # 66
HWPTAG_PARA_TEXT = HWPTAG_BEGIN + 51  # 67
HWPTAG_PARA_CHAR_SHAPE = HWPTAG_BEGIN + 52  # 68
HWPTAG_PARA_LINE_SEG = HWPTAG_BEGIN + 53  # 69
HWPTAG_PARA_RANGE_TAG = HWPTAG_BEGIN + 54  # 70
HWPTAG_CTRL_HEADER = HWPTAG_BEGIN + 55  # 71
HWPTAG_LIST_HEADER = HWPTAG_BEGIN + 56  # 72
HWPTAG_PAGE_DEF = HWPTAG_BEGIN + 57
HWPTAG_TABLE = HWPTAG_BEGIN + 61  # 77


# ---------------------------------------------------------------------------
# 저수준 레코드 파서
# ---------------------------------------------------------------------------

@dataclass
class Record:
    tag: int
    level: int
    data: bytes
    children: list["Record"] = field(default_factory=list)


def _read_records_flat(stream: bytes) -> list[Record]:
    """압축 해제된 스트림에서 모든 레코드를 평면 리스트로 읽는다."""
    out: list[Record] = []
    pos = 0
    n = len(stream)
    while pos + 4 <= n:
        header = struct.unpack("<I", stream[pos : pos + 4])[0]
        pos += 4
        tag = header & 0x3FF
        level = (header >> 10) & 0x3FF
        size = (header >> 20) & 0xFFF
        if size == 0xFFF:
            if pos + 4 > n:
                break
            size = struct.unpack("<I", stream[pos : pos + 4])[0]
            pos += 4
        if pos + size > n:
            break
        out.append(Record(tag=tag, level=level, data=stream[pos : pos + size]))
        pos += size
    return out


def _build_tree(flat: list[Record]) -> list[Record]:
    """level 정보를 사용해 부모-자식 트리를 만든다 (level 0이 루트)."""
    roots: list[Record] = []
    # 스택: (level, record)
    stack: list[Record] = []
    for rec in flat:
        # 스택의 상단을 record.level - 1까지 축소
        while stack and stack[-1].level >= rec.level:
            stack.pop()
        if stack:
            stack[-1].children.append(rec)
        else:
            roots.append(rec)
        stack.append(rec)
    return roots


# ---------------------------------------------------------------------------
# PARA_TEXT 디코더
# ---------------------------------------------------------------------------

# HWP 5.0 spec: ch < 32 인 코드포인트는 inline control
# 그 중 0x00, 0x0A, 0x0D는 1 char (2 bytes), 나머지는 16 bytes (1 + 7 extra)로 표현된다.
_SINGLE_CHARS = {0x00, 0x0A, 0x0D}


def _decode_para_text(data: bytes) -> str:
    """PARA_TEXT 데이터(UTF-16LE + inline control)에서 가시 텍스트만 추출."""
    out: list[str] = []
    i = 0
    n = len(data)
    while i + 2 <= n:
        ch = data[i] | (data[i + 1] << 8)
        if ch < 32:
            if ch == 0x0A or ch == 0x0D:
                out.append("\n")
                i += 2
            elif ch == 0x00:
                i += 2
            else:
                # inline control: 총 16바이트 (8 u16) 소비
                i += 16
        elif 0xD800 <= ch <= 0xDFFF:
            # surrogate (HWP에서는 드물지만 안전 처리)
            i += 2
        else:
            out.append(chr(ch))
            i += 2
    return "".join(out)


# ---------------------------------------------------------------------------
# 표 / 셀 파서
# ---------------------------------------------------------------------------

def _parse_table_record(data: bytes) -> tuple[int, int]:
    """TABLE 레코드 데이터에서 (rowCount, colCount) 추출."""
    # 구조: u32 properties + u16 rowCount + u16 colCount + ...
    if len(data) < 8:
        return (0, 0)
    row_count = struct.unpack_from("<H", data, 4)[0]
    col_count = struct.unpack_from("<H", data, 6)[0]
    return (row_count, col_count)


def _parse_list_header_cell(data: bytes) -> tuple[int, int, int, int] | None:
    """LIST_HEADER(셀) 데이터에서 (col, row, colSpan, rowSpan) 추출.

    구조 (선두 부분):
        u32 paraCount
        u32 listFlag
        u16 col, u16 row, u16 colSpan, u16 rowSpan

    셀이 아닌 일반 ListHeader (페이지·각주 등)인 경우 데이터 길이가 짧다.
    """
    if len(data) < 8 + 8:
        return None
    col = struct.unpack_from("<H", data, 8)[0]
    row = struct.unpack_from("<H", data, 10)[0]
    col_span = struct.unpack_from("<H", data, 12)[0]
    row_span = struct.unpack_from("<H", data, 14)[0]
    # 명백히 비정상적인 값(예: 모두 0인 비-셀 list header)은 None
    if col_span == 0 or row_span == 0:
        return None
    return (col, row, col_span, row_span)


def _list_header_para_count(data: bytes) -> int:
    if len(data) < 4:
        return 0
    return struct.unpack_from("<I", data, 0)[0]


def _cell_text_from_paragraphs(paragraphs: list[Record]) -> str:
    lines: list[str] = []
    for p in paragraphs:
        if p.tag != HWPTAG_PARA_HEADER:
            continue
        text = _paragraph_visible_text(p).strip()
        if text:
            lines.append(text)
    return "\n".join(lines)


def _paragraph_visible_text(para_header: Record) -> str:
    """PARA_HEADER 노드의 자식 PARA_TEXT 들에서 가시 텍스트를 모은다.

    표 등의 CTRL_HEADER 자식은 텍스트 추출에서 제외 (별도 처리).
    """
    parts: list[str] = []
    for child in para_header.children:
        if child.tag == HWPTAG_PARA_TEXT:
            parts.append(_decode_para_text(child.data))
    return "".join(parts)


def _parse_table_from_ctrl(ctrl: Record) -> Table | None:
    """CTRL_HEADER(ctrlID='tbl ') 노드를 Table 객체로 변환.

    명세: 표 컨트롤의 자식은 다음 순서로 나열된다.
        TABLE
        LIST_HEADER(cell 1) + PARA_HEADER * (cell 1.paraCount)
        LIST_HEADER(cell 2) + PARA_HEADER * (cell 2.paraCount)
        ...
    즉 셀 내부 paragraph는 LIST_HEADER의 자식이 아니라 **같은 level의 sibling**으로
    저장된다. 따라서 자식 리스트를 순차 walk하면서 LIST_HEADER를 만나면 paraCount만큼
    이어지는 PARA_HEADER를 그 셀의 내용으로 묶는다.
    """
    rows = cols = 0
    cells: list[Cell] = []
    seen_addrs: set[tuple[int, int]] = set()

    children = ctrl.children
    i = 0
    n = len(children)
    while i < n:
        rec = children[i]
        if rec.tag == HWPTAG_TABLE:
            rows, cols = _parse_table_record(rec.data)
            i += 1
        elif rec.tag == HWPTAG_LIST_HEADER:
            cell_info = _parse_list_header_cell(rec.data)
            para_count = _list_header_para_count(rec.data)
            i += 1
            # 다음 para_count 개의 PARA_HEADER를 셀에 귀속
            cell_paras: list[Record] = []
            consumed = 0
            while i < n and consumed < para_count:
                nxt = children[i]
                if nxt.tag == HWPTAG_PARA_HEADER:
                    cell_paras.append(nxt)
                    consumed += 1
                    i += 1
                else:
                    # 셀 내부 paragraph 사이에 다른 컨트롤 등 잡음이 있을 수도
                    i += 1
            if cell_info is None:
                continue
            col, row, col_span, row_span = cell_info
            if (row, col) in seen_addrs:
                continue
            seen_addrs.add((row, col))
            cells.append(
                Cell(
                    row=row,
                    col=col,
                    row_span=row_span,
                    col_span=col_span,
                    text=_cell_text_from_paragraphs(cell_paras),
                )
            )
        else:
            i += 1

    if rows == 0 and cols == 0 and not cells:
        return None
    if rows == 0:
        rows = max((c.row + c.row_span for c in cells), default=0)
    if cols == 0:
        cols = max((c.col + c.col_span for c in cells), default=0)
    return Table(rows=rows, cols=cols, cells=cells)


# ---------------------------------------------------------------------------
# 컨트롤 식별 (ctrlID = 4 ASCII chars, little-endian)
# ---------------------------------------------------------------------------

def _ctrl_id(ctrl_data: bytes) -> str | None:
    """CTRL_HEADER 데이터의 ctrlID(4바이트)를 ASCII 문자열로 반환.

    bytes는 little-endian이라 'tbl ' 컨트롤은 b' lbt' 또는 그 반대 순서로 저장.
    명세: ctrlID는 4-character identifier reversed in storage; 거꾸로 뒤집어 정상화.
    """
    if len(ctrl_data) < 4:
        return None
    raw = ctrl_data[:4]
    try:
        ascii_rev = raw.decode("ascii")
    except UnicodeDecodeError:
        return None
    # 'tbl '은 storage에서 ' lbt' 로 저장됨 → reverse
    return ascii_rev[::-1]


# ---------------------------------------------------------------------------
# 공개 API
# ---------------------------------------------------------------------------

def extract_blocks_from_hwp(path: str | Path) -> list[Block]:
    """HWP 5.x 파일을 블록 시퀀스로 변환한다."""
    path = Path(path)
    blocks: list[Block] = []

    with olefile.OleFileIO(str(path)) as ole:
        # FileHeader 36바이트 위치 4바이트 = property flags
        # bit 0 = compressed, bit 1 = encrypted, bit 2 = distributed
        with ole.openstream("FileHeader") as fh:
            header = fh.read(256)
        if len(header) < 40:
            return blocks
        flags = struct.unpack_from("<I", header, 36)[0]
        compressed = bool(flags & 0x1)
        encrypted = bool(flags & 0x2)
        if encrypted:
            raise ValueError("암호화된 HWP 파일은 지원하지 않습니다.")

        # BodyText/Section* 스트림 자연정렬
        section_paths = sorted(
            ("/".join(p) for p in ole.listdir())
            if False
            else [
                "/".join(p)
                for p in ole.listdir()
                if len(p) == 2 and p[0] == "BodyText" and p[1].startswith("Section")
            ],
            key=lambda s: int(s.rsplit("Section", 1)[-1]),
        )

        for sp in section_paths:
            with ole.openstream(sp) as st:
                raw = st.read()
            if compressed:
                try:
                    raw = zlib.decompress(raw, -15)
                except zlib.error:
                    continue
            flat = _read_records_flat(raw)
            roots = _build_tree(flat)
            for para in roots:
                if para.tag != HWPTAG_PARA_HEADER:
                    continue
                blocks.extend(_para_to_blocks(para))
    return blocks


def _para_to_blocks(para: Record) -> list[Block]:
    """PARA_HEADER(레벨0) 한 개를 블록(들)로 변환.

    paragraph 안의 가시 텍스트가 있으면 Paragraph 블록을 한 개 만들고,
    paragraph 안의 표 컨트롤은 별도 TableBlock으로 이어붙인다.
    텍스트와 표가 같이 들어있을 수도 있으므로 둘 다 만든다.
    """
    out: list[Block] = []
    text = _paragraph_visible_text(para).strip()
    if text:
        out.append(Paragraph(text=text))
    for child in para.children:
        if child.tag != HWPTAG_CTRL_HEADER:
            continue
        ctrl_id = _ctrl_id(child.data)
        if ctrl_id == "tbl ":
            tbl = _parse_table_from_ctrl(child)
            if tbl is not None:
                out.append(TableBlock(tbl))
    return out
