"""hwpxl 로컬 웹 앱.

- ``GET /`` — 업로드 폼
- ``POST /convert`` — 파일 업로드 → .xlsx 다운로드
- ``POST /view`` — 파일 업로드 → 미리보기 HTML 반환 (브라우저에 inline)
"""
from __future__ import annotations

import shutil
import tempfile
from pathlib import Path
from urllib.parse import quote

from fastapi import BackgroundTasks, FastAPI, File, Request, UploadFile
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

from hwpxl import (
    ConversionError,
    HwpFormat,
    __version__,
    convert_to_xlsx,
    detect_format,
    extract_blocks,
    render_body,
)


BASE_DIR = Path(__file__).resolve().parent
templates = Jinja2Templates(directory=str(BASE_DIR / "templates"))

app = FastAPI(title="hwpxl", version=__version__)
app.mount("/static", StaticFiles(directory=str(BASE_DIR / "static")), name="static")

MAX_UPLOAD_BYTES = 50 * 1024 * 1024  # 50MB


async def _save_upload(file: UploadFile, dst: Path) -> int:
    total = 0
    with dst.open("wb") as out:
        while True:
            chunk = await file.read(1024 * 1024)
            if not chunk:
                break
            total += len(chunk)
            if total > MAX_UPLOAD_BYTES:
                return total
            out.write(chunk)
    return total


def _typed_path(tmpdir: Path, stem: str, fmt: HwpFormat) -> Path:
    ext = {HwpFormat.HWP: ".hwp", HwpFormat.HWPX: ".hwpx", HwpFormat.ODT: ".odt"}[fmt]
    return tmpdir / f"{stem}{ext}"


@app.get("/", response_class=HTMLResponse)
async def index(request: Request) -> HTMLResponse:
    return templates.TemplateResponse(request, "index.html", {"version": __version__})


@app.post("/convert", response_model=None)
async def convert_route(
    background_tasks: BackgroundTasks,
    file: UploadFile = File(...),
) -> FileResponse | JSONResponse:
    original_name = file.filename or "uploaded"
    safe_stem = Path(original_name).stem or "uploaded"

    tmpdir = Path(tempfile.mkdtemp(prefix="hwpxl_"))
    background_tasks.add_task(shutil.rmtree, tmpdir, ignore_errors=True)

    raw_path = tmpdir / "input.bin"
    total = await _save_upload(file, raw_path)
    if total > MAX_UPLOAD_BYTES:
        return JSONResponse(
            status_code=413,
            content={"error": f"파일이 너무 큽니다 (>{MAX_UPLOAD_BYTES // (1024 * 1024)}MB)."},
        )

    fmt = detect_format(raw_path)
    if fmt == HwpFormat.UNKNOWN:
        return JSONResponse(
            status_code=400,
            content={"error": "HWP(.hwp) / HWPX(.hwpx) / ODT(.odt) 형식이 아닙니다."},
        )
    typed = _typed_path(tmpdir, safe_stem, fmt)
    raw_path.rename(typed)

    try:
        out_path = convert_to_xlsx(typed, tmpdir)
    except ConversionError as e:
        return JSONResponse(status_code=500, content={"error": str(e)})

    download_name = f"{safe_stem}.xlsx"
    return FileResponse(
        path=out_path,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        filename=download_name,
        headers={
            "Content-Disposition": f"attachment; filename*=UTF-8''{quote(download_name)}",
        },
    )


@app.post("/view", response_model=None)
async def view_route(
    background_tasks: BackgroundTasks,
    file: UploadFile = File(...),
) -> HTMLResponse | JSONResponse:
    original_name = file.filename or "uploaded"
    safe_stem = Path(original_name).stem or "uploaded"

    tmpdir = Path(tempfile.mkdtemp(prefix="hwpxl_"))
    background_tasks.add_task(shutil.rmtree, tmpdir, ignore_errors=True)

    raw_path = tmpdir / "input.bin"
    total = await _save_upload(file, raw_path)
    if total > MAX_UPLOAD_BYTES:
        return JSONResponse(
            status_code=413,
            content={"error": f"파일이 너무 큽니다 (>{MAX_UPLOAD_BYTES // (1024 * 1024)}MB)."},
        )

    fmt = detect_format(raw_path)
    if fmt == HwpFormat.UNKNOWN:
        return JSONResponse(
            status_code=400,
            content={"error": "HWP(.hwp) / HWPX(.hwpx) / ODT(.odt) 형식이 아닙니다."},
        )
    typed = _typed_path(tmpdir, safe_stem, fmt)
    raw_path.rename(typed)

    try:
        blocks = extract_blocks(typed)
    except ConversionError as e:
        return JSONResponse(status_code=500, content={"error": str(e)})

    return HTMLResponse(content=render_body(blocks))


@app.get("/health")
async def health() -> dict[str, str]:
    return {"status": "ok", "version": __version__}
