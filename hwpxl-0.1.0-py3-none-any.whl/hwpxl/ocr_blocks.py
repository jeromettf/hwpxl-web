"""OCR(Tesseract 등)로 얻은 단어+좌표 데이터를 ``Block`` 시퀀스로 변환한다.

브라우저 측에서 PDF.js로 페이지를 캔버스에 렌더한 뒤 Tesseract.js로 OCR을 돌리면
페이지별 단어 리스트(``[{y, x0, x1, text}, ...]``)를 얻을 수 있다. 그 데이터를 받아
페이지 헤딩 + 좌표 기반 표 추정으로 Block 시퀀스를 만든다.

좌표는 **이미지(canvas) 픽셀 좌표계**를 따른다 — y가 위쪽일수록 작음.
PDF 좌표(y가 위쪽일수록 큼)와 반대이므로 내부에서 y를 뒤집어 처리한다.

OCR 데이터에는 격자선 정보가 없으므로, ``pdf_reader._heuristic_page_blocks`` 와 같은
좌표 클러스터링 휴리스틱을 사용한다.
"""
from __future__ import annotations

from typing import Iterable

from hwpxl.document import Block, Paragraph
from hwpxl.pdf_reader import _heuristic_page_blocks


def extract_blocks_from_ocr(pages: Iterable[dict]) -> list[Block]:
    """OCR 결과를 Block 시퀀스로 변환.

    각 페이지는 다음 형태의 dict:

    .. code-block:: json

        {
          "page_num": 1,
          "words": [
            {"text": "001", "x0": 19.3, "x1": 35.1, "y0": 644.8, "y1": 656.0},
            ...
          ]
        }

    좌표는 **PDF 좌표계(y는 아래가 0)** 로 통일해서 입력한다. 호출 측에서 이미지
    좌표계(y는 위가 0)를 쓴다면 ``y = page_height - image_y`` 로 뒤집어 전달할 것.
    """
    blocks: list[Block] = []
    for page in pages:
        page_num = page.get("page_num", 0)
        words = page.get("words") or []

        # 페이지 헤딩
        blocks.append(Paragraph(text=f"— 페이지 {page_num} —", level=2))

        if not words:
            continue

        # 휴리스틱 처리기에 맞는 튜플 형태로 변환:
        # (y, x0, x1, text, [words]) — 한 단어가 한 라인 역할.
        # 같은 y로 묶이면 같은 행, x로 컬럼 클러스터링.
        text_items: list[tuple[float, float, float, str, list]] = []
        for w in words:
            text = str(w.get("text", "")).strip()
            if not text:
                continue
            y = float(w.get("y0", 0))
            x0 = float(w.get("x0", 0))
            x1 = float(w.get("x1", x0 + 1))
            # 단어 단위 fallback도 자기 자신
            text_items.append((y, x0, x1, text, [(y, x0, x1, text)]))

        if text_items:
            blocks.extend(_heuristic_page_blocks(text_items))
    return blocks
