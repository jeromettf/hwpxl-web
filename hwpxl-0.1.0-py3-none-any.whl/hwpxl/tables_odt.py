from __future__ import annotations

import zipfile
from pathlib import Path

from lxml import etree

from hwpxl.tables_hwpx import Cell, Table


TABLE_NS = "urn:oasis:names:tc:opendocument:xmlns:table:1.0"
TEXT_NS = "urn:oasis:names:tc:opendocument:xmlns:text:1.0"

_TABLE = f"{{{TABLE_NS}}}table"
_TABLE_ROW = f"{{{TABLE_NS}}}table-row"
_TABLE_CELL = f"{{{TABLE_NS}}}table-cell"
_COVERED_CELL = f"{{{TABLE_NS}}}covered-table-cell"
_NUM_COLS_REPEATED = f"{{{TABLE_NS}}}number-columns-repeated"
_NUM_COLS_SPANNED = f"{{{TABLE_NS}}}number-columns-spanned"
_NUM_ROWS_SPANNED = f"{{{TABLE_NS}}}number-rows-spanned"
_NUM_ROWS_REPEATED = f"{{{TABLE_NS}}}number-rows-repeated"


def _cell_text(cell: etree._Element) -> str:
    """ODT 셀 안의 텍스트를 줄바꿈으로 이어 반환한다."""
    lines: list[str] = []
    for p in cell.iter():
        tag = etree.QName(p).localname
        if tag in ("p", "h"):
            text = "".join(p.itertext()).strip()
            if text:
                lines.append(text)
    return "\n".join(lines)


def _parse_table(tbl: etree._Element) -> Table:
    """ODT의 <table:table> 요소를 Table dataclass로 변환.

    ODT는 비어 있는 셀이나 반복 셀에 ``number-columns-repeated`` / ``number-rows-repeated``를
    사용한다. 또한 병합된 영역 안에는 ``<covered-table-cell>``이 들어가므로,
    실제 콘텐츠가 있는 ``<table-cell>``만 좌표 매핑한다.
    """
    cells: list[Cell] = []
    row_idx = 0
    max_col = 0

    for tr in tbl.findall(_TABLE_ROW):
        rows_repeated = int(tr.get(_NUM_ROWS_REPEATED, "1") or 1)
        for _ in range(rows_repeated):
            col_idx = 0
            for tc in tr:
                tag = etree.QName(tc).localname
                if tag == "covered-table-cell":
                    cols_rep = int(tc.get(_NUM_COLS_REPEATED, "1") or 1)
                    col_idx += cols_rep
                    continue
                if tag != "table-cell":
                    continue

                cols_spanned = int(tc.get(_NUM_COLS_SPANNED, "1") or 1)
                rows_spanned = int(tc.get(_NUM_ROWS_SPANNED, "1") or 1)
                cols_repeated = int(tc.get(_NUM_COLS_REPEATED, "1") or 1)
                text = _cell_text(tc)

                for _r in range(cols_repeated):
                    cells.append(
                        Cell(
                            row=row_idx,
                            col=col_idx,
                            row_span=rows_spanned,
                            col_span=cols_spanned,
                            text=text,
                        )
                    )
                    col_idx += cols_spanned

            max_col = max(max_col, col_idx)
            row_idx += 1

    max_row = max((c.row + c.row_span for c in cells), default=0)
    return Table(rows=max_row, cols=max_col, cells=cells)


def extract_tables_from_odt(path: str | Path) -> list[Table]:
    """ODT(OpenDocument Text) 파일에서 모든 표를 추출한다.

    중첩 표(셀 안의 표)는 별도 Table 항목으로 추가된다 — 부모 셀의 텍스트에는 내부 표
    내용이 들어가지 않도록 별도 항목으로만 처리한다.
    """
    path = Path(path)
    tables: list[Table] = []

    with zipfile.ZipFile(path) as zf:
        if "content.xml" not in zf.namelist():
            return []
        data = zf.read("content.xml")

    root = etree.fromstring(data)
    for tbl in root.iter(_TABLE):
        tables.append(_parse_table(tbl))
    return tables
