from __future__ import annotations

from enum import Enum
from pathlib import Path


class HwpFormat(str, Enum):
    HWP = "hwp"
    HWPX = "hwpx"
    ODT = "odt"
    PDF = "pdf"
    UNKNOWN = "unknown"


OLE_MAGIC = b"\xD0\xCF\x11\xE0\xA1\xB1\x1A\xE1"
ZIP_MAGIC = b"PK\x03\x04"
PDF_MAGIC = b"%PDF-"


def detect_format(path: str | Path) -> HwpFormat:
    """파일 앞부분의 매직바이트로 HWP/HWPX 형식을 판별한다.

    확장자가 아닌 실제 바이트 시그니처를 보므로 확장자가 잘못 붙은 파일도 안전하게 처리된다.
    HWPX는 사실 ZIP이므로, ZIP 시그니처 + `mimetype` 엔트리가 hwpx인지까지 확인한다.
    """
    p = Path(path)
    with p.open("rb") as f:
        head = f.read(8)

    if head.startswith(OLE_MAGIC):
        return HwpFormat.HWP

    if head.startswith(PDF_MAGIC):
        return HwpFormat.PDF

    if head.startswith(ZIP_MAGIC):
        try:
            import zipfile

            with zipfile.ZipFile(p) as zf:
                names = zf.namelist()
                mt = ""
                if "mimetype" in names:
                    mt = zf.read("mimetype").decode("ascii", errors="ignore").strip()
                # HWPX: mimetype="application/hwp+zip" 또는 Contents/section*.xml 존재
                if "hwp" in mt:
                    return HwpFormat.HWPX
                if any(n.startswith("Contents/section") for n in names):
                    return HwpFormat.HWPX
                # ODT: mimetype="application/vnd.oasis.opendocument.text" 또는
                # content.xml 존재 (확장자가 .hwp로 잘못 붙은 케이스도 흡수)
                if "opendocument.text" in mt:
                    return HwpFormat.ODT
                if "content.xml" in names and "styles.xml" in names:
                    return HwpFormat.ODT
        except zipfile.BadZipFile:
            pass

    return HwpFormat.UNKNOWN
