from __future__ import annotations

import zipfile
from dataclasses import dataclass, field
from pathlib import Path

from lxml import etree


HP_NS = "http://www.hancom.co.kr/hwpml/2011/paragraph"
NSMAP = {"hp": HP_NS}


@dataclass
class Cell:
    row: int
    col: int
    row_span: int
    col_span: int
    text: str


@dataclass
class Table:
    rows: int
    cols: int
    cells: list[Cell] = field(default_factory=list)


def _cell_text(tc: etree._Element) -> str:
    """셀(<hp:tc>) 내부의 모든 <hp:t> 텍스트를 줄바꿈으로 이어서 반환."""
    texts: list[str] = []
    # 같은 <hp:p>(문단) 안의 <hp:t>는 공백으로 합치고, 문단 사이는 줄바꿈.
    for p in tc.findall(f".//{{{HP_NS}}}p"):
        parts = [t.text or "" for t in p.findall(f".//{{{HP_NS}}}t")]
        line = "".join(parts).strip()
        if line:
            texts.append(line)
    return "\n".join(texts)


def _parse_table(tbl: etree._Element) -> Table:
    rows = int(tbl.get("rowCnt", "0") or 0)
    cols = int(tbl.get("colCnt", "0") or 0)
    table = Table(rows=rows, cols=cols)

    for tr in tbl.findall(f"{{{HP_NS}}}tr"):
        for tc in tr.findall(f"{{{HP_NS}}}tc"):
            addr = tc.find(f"{{{HP_NS}}}cellAddr")
            span = tc.find(f"{{{HP_NS}}}cellSpan")
            if addr is None:
                continue
            r = int(addr.get("rowAddr", "0") or 0)
            c = int(addr.get("colAddr", "0") or 0)
            rs = int(span.get("rowSpan", "1") or 1) if span is not None else 1
            cs = int(span.get("colSpan", "1") or 1) if span is not None else 1
            table.cells.append(
                Cell(row=r, col=c, row_span=rs, col_span=cs, text=_cell_text(tc))
            )
    return table


def extract_tables_from_hwpx(path: str | Path) -> list[Table]:
    """HWPX 파일에서 모든 표를 추출하여 Table 리스트로 반환한다.

    표는 ``Contents/section*.xml`` 들에 분산되어 있으므로 자연 정렬 순으로 모두 훑는다.
    중첩 표(셀 안의 표)는 별도 Table 항목으로 분리되며, 부모 셀에는 내부 표의 텍스트는 들어가지 않는다.
    """
    path = Path(path)
    tables: list[Table] = []

    with zipfile.ZipFile(path) as zf:
        section_names = sorted(
            n for n in zf.namelist()
            if n.startswith("Contents/section") and n.endswith(".xml")
        )
        for name in section_names:
            data = zf.read(name)
            try:
                root = etree.fromstring(data)
            except etree.XMLSyntaxError:
                continue
            for tbl in root.iter(f"{{{HP_NS}}}tbl"):
                tables.append(_parse_table(tbl))

    return tables
