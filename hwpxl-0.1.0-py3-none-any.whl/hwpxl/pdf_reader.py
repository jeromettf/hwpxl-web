"""PDF 파일을 본문 블록 시퀀스로 변환한다.

pdfminer.six로 페이지별 텍스트 라인을 (y, x) 좌표와 함께 추출한 뒤,

1. 같은 y 좌표 근처의 라인들은 같은 **행**으로 묶고,
2. 전체 페이지의 x 좌표를 클러스터링해 **열 경계**를 추정한다.

행이 2개 이상의 열에 걸쳐 있다고 판단되면 표로, 단일 열이면 본문 문단으로 출력한다.
완벽한 표 인식은 불가능하지만(특히 그래픽 기반 PDF), 정형화된 표가 있는 행정 문서에는
충분히 쓸 만하다.
"""
from __future__ import annotations

from pathlib import Path

from hwpxl.document import Block, Paragraph, TableBlock
from hwpxl.tables_hwpx import Cell, Table


# 같은 행으로 묶을 y 허용오차 (포인트). PDF 폰트 1줄 높이가 대략 10~14pt.
_Y_TOLERANCE = 4.0
# 같은 열로 묶을 x 허용오차.
_X_TOLERANCE = 6.0


def _iter_text_lines(path: str | Path):
    """``(page_num, y, x, x_end, text)`` 튜플을 yield."""
    from pdfminer.high_level import extract_pages
    from pdfminer.layout import LTTextContainer, LTTextLine

    for page_num, page in enumerate(extract_pages(str(path)), start=1):
        for element in page:
            if not isinstance(element, LTTextContainer):
                continue
            for line in element:
                if not isinstance(line, LTTextLine):
                    continue
                text = line.get_text().rstrip("\n")
                if not text.strip():
                    continue
                yield page_num, line.y0, line.x0, line.x1, text


def _cluster_x_positions(xs: list[float], tol: float = _X_TOLERANCE) -> list[float]:
    """페이지의 모든 라인 x0를 모아 열 경계 후보를 만든다.

    정렬 후 ``tol`` 이내로 가까운 값은 같은 그룹으로 묶고, 각 그룹의 평균을 열 기준 x로 사용.
    """
    if not xs:
        return []
    sorted_xs = sorted(xs)
    groups: list[list[float]] = [[sorted_xs[0]]]
    for x in sorted_xs[1:]:
        if x - groups[-1][-1] <= tol:
            groups[-1].append(x)
        else:
            groups.append([x])
    return [sum(g) / len(g) for g in groups]


def _row_lines_to_block(
    row_lines: list[tuple[float, float, float, str]],
    col_xs: list[float],
) -> Block:
    """한 행(같은 y)의 라인들을 Paragraph 또는 1행짜리 Table로 변환."""
    # 라인 수가 1개거나 열 클러스터가 1개면 본문 문단으로
    if len(row_lines) <= 1 or len(col_xs) <= 1:
        text = " ".join(t for *_x, t in row_lines).strip()
        return Paragraph(text=text)

    # 각 라인을 가장 가까운 열에 배정
    cells: list[Cell] = []
    used_cols: set[int] = set()
    for _y, x, _xe, text in sorted(row_lines, key=lambda r: r[1]):
        # x와 가장 가까운 col index 찾기
        col_idx = min(range(len(col_xs)), key=lambda i: abs(col_xs[i] - x))
        # 중복 방지: 같은 열에 두 라인이 떨어진 경우 → 텍스트 이어붙임
        existing = next((c for c in cells if c.col == col_idx), None)
        if existing is not None:
            existing.text += " " + text.strip()
        else:
            cells.append(
                Cell(row=0, col=col_idx, row_span=1, col_span=1, text=text.strip())
            )
            used_cols.add(col_idx)

    # 표로 의미가 있으려면 최소 2개 셀
    if len(cells) < 2:
        text = " ".join(c.text for c in cells)
        return Paragraph(text=text)

    cols_count = len(col_xs)
    return TableBlock(Table(rows=1, cols=cols_count, cells=cells))


def _merge_consecutive_table_rows(blocks: list[Block]) -> list[Block]:
    """연속된 1행짜리 TableBlock 들을 하나의 다행 Table로 합친다."""
    merged: list[Block] = []
    buffer: list[TableBlock] = []

    def flush():
        if not buffer:
            return
        if len(buffer) == 1:
            merged.append(buffer[0])
            buffer.clear()
            return
        # 여러 행 → 합치기. 열 수는 max로.
        cols = max(b.table.cols for b in buffer)
        cells: list[Cell] = []
        for r_idx, tb in enumerate(buffer):
            for c in tb.table.cells:
                cells.append(
                    Cell(
                        row=r_idx,
                        col=c.col,
                        row_span=c.row_span,
                        col_span=c.col_span,
                        text=c.text,
                    )
                )
        merged.append(TableBlock(Table(rows=len(buffer), cols=cols, cells=cells)))
        buffer.clear()

    for b in blocks:
        if isinstance(b, TableBlock) and b.table.rows == 1:
            buffer.append(b)
        else:
            flush()
            merged.append(b)
    flush()
    return merged


def extract_blocks_from_pdf(path: str | Path) -> list[Block]:
    path = Path(path)
    blocks: list[Block] = []

    # 페이지별로 처리
    pages: dict[int, list[tuple[float, float, float, str]]] = {}
    for page_num, y, x, xe, text in _iter_text_lines(path):
        pages.setdefault(page_num, []).append((y, x, xe, text))

    for page_num in sorted(pages):
        page_lines = pages[page_num]
        # 페이지 헤딩 (level=2)
        blocks.append(Paragraph(text=f"— 페이지 {page_num} —", level=2))

        # 모든 x0를 모아 열 경계 추정
        col_xs = _cluster_x_positions([x for _y, x, _xe, _t in page_lines])

        # y 내림차순(위→아래)으로 정렬한 뒤 행 묶음
        page_lines.sort(key=lambda r: (-r[0], r[1]))
        row_blocks: list[Block] = []
        current_row: list[tuple[float, float, float, str]] = []
        current_y: float | None = None
        for y, x, xe, text in page_lines:
            if current_y is None or abs(y - current_y) <= _Y_TOLERANCE:
                current_row.append((y, x, xe, text))
                current_y = y if current_y is None else (current_y + y) / 2
            else:
                row_blocks.append(_row_lines_to_block(current_row, col_xs))
                current_row = [(y, x, xe, text)]
                current_y = y
        if current_row:
            row_blocks.append(_row_lines_to_block(current_row, col_xs))

        # 연속된 1행 table들을 다행 table로 합쳐 보여주기 좋게
        blocks.extend(_merge_consecutive_table_rows(row_blocks))

    return blocks
