"""PDF 파일을 본문 블록 시퀀스로 변환한다.

전략은 두 가지를 순서대로 시도한다.

1. **표 격자 기반 (정확)** — PDF에 표 ``<table>`` 의 가로/세로 격자선(``LTLine``)이 그려져
   있으면, 그 선들로 행/열 경계를 만들고, 각 텍스트 라인을 자신의 좌표가 속한 셀에
   매핑한다. 회계 전표·공문 등 정형 양식 PDF에 매우 정확하다.

2. **좌표 휴리스틱 (fallback)** — 격자선이 거의 없는 PDF에서는 라인의 y 좌표를 묶어
   행을, x 좌표를 클러스터링해 열을 추정한다.

격자 영역 밖의 텍스트(타이틀, 페이지 번호 등)는 ``Paragraph`` 로 출력한다.
"""
from __future__ import annotations

from pathlib import Path

from hwpxl.document import Block, Paragraph, TableBlock
from hwpxl.tables_hwpx import Cell, Table


# 격자선 좌표 클러스터 허용오차 (포인트). PDF는 보통 같은 격자선이라도 0.x pt 차이로
# 여러 번 그려진다. 1pt 이내는 동일 격자선으로 본다.
_GRID_TOL = 1.5
# 휴리스틱 모드의 y 행 묶음 허용오차.
_Y_TOLERANCE = 4.0
_X_TOLERANCE = 6.0


# ---------------------------------------------------------------------------
# 격자선 수집 & 클러스터링
# ---------------------------------------------------------------------------

def _collect_grid_segments(page, min_h_length: float, min_v_length: float):
    """페이지의 가로선/세로선을 (y, x_min, x_max), (x, y_min, y_max) 리스트로 반환.

    점선의 dot 같은 매우 짧은 선분(노이즈)은 ``min_*_length`` 임계로 걸러낸다.
    """
    from pdfminer.layout import LTLine, LTRect

    horizontals: list[tuple[float, float, float]] = []
    verticals: list[tuple[float, float, float]] = []

    def add_line(x0, y0, x1, y1):
        if abs(y0 - y1) < 0.5 and abs(x1 - x0) >= min_h_length:
            horizontals.append((y0, min(x0, x1), max(x0, x1)))
        elif abs(x0 - x1) < 0.5 and abs(y1 - y0) >= min_v_length:
            verticals.append((x0, min(y0, y1), max(y0, y1)))

    for el in page:
        if isinstance(el, LTLine):
            x0, y0, x1, y1 = el.bbox
            add_line(x0, y0, x1, y1)
        elif isinstance(el, LTRect):
            # 사각형은 4개의 선분 (사각형 자체는 항상 격자로 인정 → 임계 우회)
            x0, y0, x1, y1 = el.bbox
            if abs(x1 - x0) >= 1.0 and abs(y1 - y0) >= 1.0:
                horizontals.append((y0, x0, x1))
                horizontals.append((y1, x0, x1))
                verticals.append((x0, y0, y1))
                verticals.append((x1, y0, y1))
    return horizontals, verticals


def _cluster(values: list[float], tol: float = _GRID_TOL) -> list[float]:
    """비슷한 값을 묶어 평균값 리스트로 반환 (정렬됨)."""
    if not values:
        return []
    sv = sorted(values)
    groups: list[list[float]] = [[sv[0]]]
    for v in sv[1:]:
        if v - groups[-1][-1] <= tol:
            groups[-1].append(v)
        else:
            groups.append([v])
    return [sum(g) / len(g) for g in groups]


# ---------------------------------------------------------------------------
# 격자 기반 표 추출
# ---------------------------------------------------------------------------

def _drop_close(values_sorted: list[float], min_gap: float) -> list[float]:
    """정렬된 값 시퀀스에서 인접한 값 사이가 ``min_gap`` 미만이면 뒤의 값은 버린다.

    표 격자의 sub-divider(예: 셀 내부 한 줄을 가르는 가로선)가 메인 행/열 경계와 같이
    잡혔을 때, 그 sub-divider를 제거해 한 데이터 행/열이 여러 row/col로 쪼개지는 것을 막는다.
    """
    if not values_sorted:
        return values_sorted
    out = [values_sorted[0]]
    for v in values_sorted[1:]:
        if v - out[-1] >= min_gap:
            out.append(v)
    return out


# 최소 row 높이/열 폭 (pt). 너무 좁은 격자 구간은 같은 컬럼/행의 sub-divider로 보고 흡수.
# col은 한국어 본문 한 글자가 ~10pt 정도 차지하므로, 의미 있는 셀은 보통 30pt 이상.
_MIN_ROW_HEIGHT = 18.0
_MIN_COL_WIDTH = 30.0


def _extract_grid_region(horizontals, verticals):
    """가로선/세로선으로 표 영역(bbox)과 행/열 경계 좌표를 만든다.

    1) 같은 격자로 클러스터링된 y/x 들 중에서 너무 가까운(``< _MIN_ROW_HEIGHT/COL_WIDTH``)
       것은 메인 격자선 옆에 붙은 sub-divider로 간주해 제거한다.
    2) 남은 좌표로 row/col 경계 구간을 만든다.
    """
    y_centers = _cluster([y for y, _x0, _x1 in horizontals])
    x_centers = _cluster([x for x, _y0, _y1 in verticals])

    # sub-divider 제거: 위→아래/좌→우 순으로 너무 가까운 좌표는 버린다.
    y_centers_sorted = sorted(y_centers)
    y_centers_sorted = _drop_close(y_centers_sorted, _MIN_ROW_HEIGHT)
    x_centers_sorted = _drop_close(sorted(x_centers), _MIN_COL_WIDTH)

    if len(y_centers_sorted) < 2 or len(x_centers_sorted) < 2:
        return None

    # row 경계 = 인접 y 사이 구간 (위→아래 순)
    y_desc = sorted(y_centers_sorted, reverse=True)
    row_ranges = [(y_desc[i + 1], y_desc[i]) for i in range(len(y_desc) - 1)]
    col_ranges = [
        (x_centers_sorted[i], x_centers_sorted[i + 1])
        for i in range(len(x_centers_sorted) - 1)
    ]
    if not row_ranges or not col_ranges:
        return None

    # row_ranges는 위→아래 순. 첫 row의 hi가 표 상단, 마지막 row의 lo가 표 하단.
    table_bbox = (
        col_ranges[0][0],       # x_left
        row_ranges[-1][0],      # y_bottom (가장 작은 y)
        col_ranges[-1][1],      # x_right
        row_ranges[0][1],       # y_top (가장 큰 y)
    )
    return row_ranges, col_ranges, table_bbox


def _which_range(value: float, ranges: list[tuple[float, float]]) -> int | None:
    """value 가 어느 range 에 속하는지 인덱스 반환. 어디에도 안 들어가면 None."""
    for i, (lo, hi) in enumerate(ranges):
        if lo <= value <= hi:
            return i
    return None


def _build_table_from_grid(row_ranges, col_ranges, text_lines) -> Table:
    """각 텍스트 라인을 (row, col) 셀에 매핑하여 Table 생성.

    라인이 단일 컬럼에 들어가면 그 라인 전체를 그 셀로, 여러 컬럼에 걸쳐 있으면 단어로
    잘라 각 단어를 개별 셀에 배치한다. 같은 셀에 들어가는 여러 라인은 줄바꿈으로 결합.
    아무 셀도 채워지지 않은 행/열은 제거하여 깔끔하게 만든다.
    """
    grid: dict[tuple[int, int], list[tuple[float, float, str]]] = {}

    for y, x0, x1, text, words in text_lines:
        ri = _which_range(y, row_ranges)
        if ri is None:
            continue
        c_left = _which_range(x0, col_ranges)
        c_right = _which_range(x1, col_ranges)
        if c_left is not None and c_left == c_right:
            # 라인 전체가 한 컬럼 안에 있음 → 라인 그대로
            grid.setdefault((ri, c_left), []).append((-y, x0, text))
        else:
            # 여러 컬럼에 걸침 → 단어 단위로 분리해서 매핑
            for wy, wx0, wx1, wtext in words:
                wcx = (wx0 + wx1) / 2
                wci = _which_range(wcx, col_ranges)
                if wci is None:
                    continue
                grid.setdefault((ri, wci), []).append((-wy, wx0, wtext))

    if not grid:
        return Table(rows=0, cols=0, cells=[])

    # 실제 사용된 row/col 만 남기고 인덱스 재매핑
    used_rows = sorted({r for r, _c in grid})
    used_cols = sorted({c for _r, c in grid})
    row_map = {old: new for new, old in enumerate(used_rows)}
    col_map = {old: new for new, old in enumerate(used_cols)}

    cells: list[Cell] = []
    for (r, c), parts in grid.items():
        parts.sort()  # (-y, x) 순 → 위→아래, 좌→우
        # 같은 y 의 단어들은 공백으로, 다른 y 사이는 줄바꿈으로 결합
        lines: list[str] = []
        cur_words: list[str] = []
        cur_y: float | None = None
        for ny, _x, t in parts:
            if cur_y is None or abs(ny - cur_y) < 2.0:
                cur_words.append(t)
                cur_y = ny
            else:
                lines.append(" ".join(cur_words))
                cur_words = [t]
                cur_y = ny
        if cur_words:
            lines.append(" ".join(cur_words))
        text = "\n".join(lines).strip()
        if not text:
            continue
        cells.append(
            Cell(
                row=row_map[r],
                col=col_map[c],
                row_span=1,
                col_span=1,
                text=text,
            )
        )

    return Table(rows=len(used_rows), cols=len(used_cols), cells=cells)


# ---------------------------------------------------------------------------
# Fallback: 좌표 휴리스틱 (격자선이 거의 없는 PDF용)
# ---------------------------------------------------------------------------

def _cluster_x_positions(xs: list[float], tol: float = _X_TOLERANCE) -> list[float]:
    return _cluster(xs, tol)


def _row_lines_to_block(row_lines, col_xs: list[float]) -> Block:
    # row_lines: (y, x0, x1, text, words) 시퀀스
    if len(row_lines) <= 1 or len(col_xs) <= 1:
        text = " ".join(item[3] for item in row_lines).strip()
        return Paragraph(text=text)

    cells: list[Cell] = []
    for item in sorted(row_lines, key=lambda r: r[1]):
        _y, x, _xe, text, _words = item
        col_idx = min(range(len(col_xs)), key=lambda i: abs(col_xs[i] - x))
        existing = next((c for c in cells if c.col == col_idx), None)
        if existing is not None:
            existing.text += " " + text.strip()
        else:
            cells.append(
                Cell(row=0, col=col_idx, row_span=1, col_span=1, text=text.strip())
            )

    if len(cells) < 2:
        text = " ".join(c.text for c in cells)
        return Paragraph(text=text)
    return TableBlock(Table(rows=1, cols=len(col_xs), cells=cells))


def _merge_consecutive_table_rows(blocks: list[Block]) -> list[Block]:
    merged: list[Block] = []
    buffer: list[TableBlock] = []

    def flush():
        if not buffer:
            return
        if len(buffer) == 1:
            merged.append(buffer[0])
            buffer.clear()
            return
        cols = max(b.table.cols for b in buffer)
        cells: list[Cell] = []
        for r_idx, tb in enumerate(buffer):
            for c in tb.table.cells:
                cells.append(
                    Cell(row=r_idx, col=c.col, row_span=c.row_span, col_span=c.col_span, text=c.text)
                )
        merged.append(TableBlock(Table(rows=len(buffer), cols=cols, cells=cells)))
        buffer.clear()

    for b in blocks:
        if isinstance(b, TableBlock) and b.table.rows == 1:
            buffer.append(b)
        else:
            flush()
            merged.append(b)
    flush()
    return merged


def _heuristic_page_blocks(text_lines) -> list[Block]:
    blocks: list[Block] = []
    if not text_lines:
        return blocks
    col_xs = _cluster_x_positions([item[1] for item in text_lines])
    sorted_lines = sorted(text_lines, key=lambda r: (-r[0], r[1]))
    row_blocks: list[Block] = []
    current = []
    current_y: float | None = None
    for item in sorted_lines:
        y = item[0]
        if current_y is None or abs(y - current_y) <= _Y_TOLERANCE:
            current.append(item)
            current_y = y if current_y is None else (current_y + y) / 2
        else:
            row_blocks.append(_row_lines_to_block(current, col_xs))
            current = [item]
            current_y = y
    if current:
        row_blocks.append(_row_lines_to_block(current, col_xs))
    blocks.extend(_merge_consecutive_table_rows(row_blocks))
    return blocks


# ---------------------------------------------------------------------------
# 메인 추출 (페이지 단위로 격자 우선, 안 되면 휴리스틱)
# ---------------------------------------------------------------------------

def _line_to_words(line) -> list[tuple[float, float, float, str]]:
    """``LTTextLine`` 을 (y0, word_x0, word_x1, word_text) 단어 리스트로 분할.

    공백 1개 이상은 단어 경계로 본다. 한 라인 안에서 컬럼이 다른 텍스트가 한 LTTextLine으로
    묶여 나올 수 있으므로(예: "001 복리후생비-야식" → 행번 컬럼 + 계정과목 컬럼), 단어 단위로
    분리해 각 단어를 독립적으로 컬럼에 매핑할 수 있게 한다.
    """
    from pdfminer.layout import LTChar

    chars: list = []
    for ch in line:
        if isinstance(ch, LTChar):
            chars.append(ch)

    if not chars:
        text = line.get_text().rstrip("\n").strip()
        if text:
            return [(line.y0, line.x0, line.x1, text)]
        return []

    # 한국어/영어 폰트 한 글자 너비의 50% 정도를 단어 구분 임계값으로 사용
    avg_w = sum((c.x1 - c.x0) for c in chars) / max(len(chars), 1)
    gap_threshold = max(2.0, avg_w * 0.5)

    words: list[tuple[float, float, float, str]] = []
    cur_text = ""
    cur_x0 = None
    cur_x1 = None
    prev_x1 = None
    y0 = line.y0
    for c in chars:
        t = c.get_text()
        if t.isspace() or t == "\xa0":
            if cur_text:
                words.append((y0, cur_x0, cur_x1, cur_text))
                cur_text = ""
                cur_x0 = cur_x1 = None
            prev_x1 = c.x1
            continue
        # 시각적으로 큰 공백(글리프 사이 거리)이 있으면 단어 경계로 처리
        if cur_text and prev_x1 is not None and (c.x0 - prev_x1) > gap_threshold:
            words.append((y0, cur_x0, cur_x1, cur_text))
            cur_text = ""
            cur_x0 = cur_x1 = None
        if cur_x0 is None:
            cur_x0 = c.x0
        cur_text += t
        cur_x1 = c.x1
        prev_x1 = c.x1
    if cur_text:
        words.append((y0, cur_x0, cur_x1, cur_text))
    return words


def _collect_text_lines(page):
    """페이지의 텍스트 라인을 ``(y, x0, x1, text, words)`` tuple 리스트로 반환.

    - 라인 자체 좌표(``y, x0, x1, text``)는 그대로 두고,
    - 라인이 여러 컬럼에 걸쳐 있을 때 단어로 다시 자르기 위한 ``words`` 리스트도 함께 보관.
    """
    from pdfminer.layout import LTTextContainer, LTTextLine

    out: list[tuple[float, float, float, str, list[tuple[float, float, float, str]]]] = []
    for element in page:
        if not isinstance(element, LTTextContainer):
            continue
        for line in element:
            if not isinstance(line, LTTextLine):
                continue
            text = line.get_text().rstrip("\n").strip()
            if not text:
                continue
            words = _line_to_words(line)
            out.append((line.y0, line.x0, line.x1, text, words))
    return out


def _line_in_bbox(y: float, x: float, xe: float, bbox) -> bool:
    bx0, by0, bx1, by1 = bbox
    cx = (x + xe) / 2
    return bx0 <= cx <= bx1 and by0 <= y <= by1


def pdf_text_char_count(path: str | Path) -> int:
    """PDF에 들어있는 추출 가능 글자 수를 빠르게 추산한다.

    값이 매우 작으면(예: 페이지당 평균 < 50) 본문이 벡터 outline으로 변환되어 있어
    텍스트로 추출할 수 없는 PDF — UI에서 이걸 보고 OCR 분기로 전환할 수 있다.
    """
    from pdfminer.high_level import extract_text

    try:
        return len(extract_text(str(path)))
    except Exception:
        return 0


def extract_blocks_from_pdf(path: str | Path) -> list[Block]:
    from pdfminer.high_level import extract_pages

    path = Path(path)
    blocks: list[Block] = []

    for page_num, page in enumerate(extract_pages(str(path)), start=1):
        text_lines = _collect_text_lines(page)
        if not text_lines:
            continue

        # 페이지 헤딩 (level=2)
        blocks.append(Paragraph(text=f"— 페이지 {page_num} —", level=2))

        # 페이지 크기 기반 임계값: 표 외곽/주 row·col 경계로 인정할 최소 길이.
        # - 가로선: 페이지 폭의 25%(짧은 sub-divider 제외)
        # - 세로선: 페이지 높이의 8%
        # 너무 엄격해서 격자가 모자라면 점진적으로 완화한다.
        bx0, by0, bx1, by1 = page.bbox
        page_w = bx1 - bx0
        page_h = by1 - by0
        grid = None
        for h_ratio, v_ratio in ((0.25, 0.08), (0.12, 0.04), (0.05, 0.02)):
            min_h = max(30.0, page_w * h_ratio)
            min_v = max(10.0, page_h * v_ratio)
            horizontals, verticals = _collect_grid_segments(page, min_h, min_v)
            if len(horizontals) >= 4 and len(verticals) >= 4:
                grid = _extract_grid_region(horizontals, verticals)
                if grid is not None:
                    break

        if grid is not None:
            row_ranges, col_ranges, table_bbox = grid
            inside = [it for it in text_lines if _line_in_bbox(it[0], it[1], it[2], table_bbox)]
            outside = [it for it in text_lines if not _line_in_bbox(it[0], it[1], it[2], table_bbox)]

            outside_sorted = sorted(outside, key=lambda r: (-r[0], r[1]))
            above = [it for it in outside_sorted if it[0] > table_bbox[3]]
            below = [it for it in outside_sorted if it[0] < table_bbox[1]]
            for item in above:
                blocks.append(Paragraph(text=item[3]))
            if inside:
                table = _build_table_from_grid(row_ranges, col_ranges, inside)
                if table.cells:
                    blocks.append(TableBlock(table))
            for item in below:
                blocks.append(Paragraph(text=item[3]))
        else:
            blocks.extend(_heuristic_page_blocks(text_lines))

    return blocks
