from __future__ import annotations

from pathlib import Path

from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

from hwpxl.document import Block, Paragraph, TableBlock
from hwpxl.tables_hwpx import Table


_thin = Side(style="thin", color="888888")
_border = Border(left=_thin, right=_thin, top=_thin, bottom=_thin)
_wrap_center = Alignment(wrap_text=True, vertical="center", horizontal="left")
_wrap_top = Alignment(wrap_text=True, vertical="top", horizontal="left")
_header_font = Font(bold=True)
_h1_font = Font(bold=True, size=14)
_h2_font = Font(bold=True, size=12)
_table_header_fill = PatternFill("solid", fgColor="F2F2F2")


def write_tables_to_xlsx(tables: list[Table], output_path: str | Path) -> Path:
    """추출된 표들을 .xlsx 파일로 저장한다. 표 1개 = 시트 1장.

    셀 병합은 ``merge_cells``로 그대로 옮긴다. 표가 하나도 없으면 안내 메시지가 담긴
    빈 워크북을 만든다.
    """
    output_path = Path(output_path)
    wb = Workbook()
    # 기본 시트 제거
    default = wb.active
    if default is not None:
        wb.remove(default)

    if not tables:
        ws = wb.create_sheet("정보")
        ws["A1"] = "이 문서에서 추출 가능한 표가 없습니다."
        ws["A1"].font = _header_font
        wb.save(output_path)
        return output_path

    for idx, table in enumerate(tables, start=1):
        ws = wb.create_sheet(f"표{idx}")
        max_row = max((c.row + c.row_span for c in table.cells), default=0)
        max_col = max((c.col + c.col_span for c in table.cells), default=0)
        # 보기 좋게 기본 폭/높이만 가볍게 조정
        for col_idx in range(1, max(1, max_col) + 1):
            ws.column_dimensions[get_column_letter(col_idx)].width = 18

        for cell in table.cells:
            row1 = cell.row + 1
            col1 = cell.col + 1
            top_cell = ws.cell(row=row1, column=col1, value=cell.text or None)
            top_cell.alignment = _wrap_center
            top_cell.border = _border

            if cell.row_span > 1 or cell.col_span > 1:
                ws.merge_cells(
                    start_row=row1,
                    start_column=col1,
                    end_row=row1 + cell.row_span - 1,
                    end_column=col1 + cell.col_span - 1,
                )
                # 병합 영역의 모든 셀에 테두리
                for r in range(row1, row1 + cell.row_span):
                    for c in range(col1, col1 + cell.col_span):
                        ws.cell(row=r, column=c).border = _border

        # 첫 행이 헤더처럼 보이게 굵게(휴리스틱)
        if max_row >= 1:
            for col_idx in range(1, max_col + 1):
                ws.cell(row=1, column=col_idx).font = _header_font

    wb.save(output_path)
    return output_path


# ---------------------------------------------------------------------------
# 문서 전체를 한 시트에 흘려쓰는 모드 (본문 + 표)
# ---------------------------------------------------------------------------

def write_document_to_xlsx(blocks: list[Block], output_path: str | Path) -> Path:
    """블록 시퀀스를 ``문서`` 시트 한 장에 위→아래 순서로 펼친다.

    - ``Paragraph`` 는 한 행 A열에 텍스트로 들어간다. ``level >= 1``이면 굵게(크기 차등).
    - ``TableBlock`` 은 그 위치에서 ``rows × cols`` 영역으로 펼쳐진다. 셀 병합 보존.
    - 표 위·아래에는 빈 행 한 줄을 두어 가독성을 확보한다.
    - 최대 열 폭은 표의 최대 열 수에 맞춘다. 본문 행은 A열에 길게 표시.
    """
    output_path = Path(output_path)
    wb = Workbook()
    ws = wb.active
    ws.title = "문서"

    if not blocks:
        ws["A1"] = "이 문서에서 추출 가능한 내용이 없습니다."
        ws["A1"].font = _header_font
        wb.save(output_path)
        return output_path

    # 표들 중 최대 열 수를 알아내 시트 열 폭을 미리 세팅
    max_cols = 1
    for b in blocks:
        if isinstance(b, TableBlock):
            max_cols = max(max_cols, b.table.cols, 1)
    for c in range(1, max_cols + 1):
        ws.column_dimensions[get_column_letter(c)].width = 18

    row = 1
    prev_was_table = False

    for block in blocks:
        if isinstance(block, Paragraph):
            if prev_was_table:
                row += 1  # 표 다음에는 빈 행
                prev_was_table = False

            cell = ws.cell(row=row, column=1, value=block.text)
            cell.alignment = _wrap_top
            if block.level == 1:
                cell.font = _h1_font
            elif block.level >= 2:
                cell.font = _h2_font
            # 헤딩이 아니더라도, 짧은 줄이면 A열에 들어가고 어차피 max_cols만큼 공간이 있음
            # 본문은 A열 ~ max_cols 열에 걸쳐 보이도록 병합 (max_cols >= 2 인 경우)
            if max_cols >= 2:
                ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=max_cols)
            row += 1
        elif isinstance(block, TableBlock):
            if not prev_was_table:
                # 표 위에 빈 행 한 줄
                row += 1
            table_start = row
            table = block.table
            for cell in table.cells:
                r = table_start + cell.row
                c = cell.col + 1
                top = ws.cell(row=r, column=c, value=cell.text or None)
                top.alignment = _wrap_top
                top.border = _border
                # 표의 첫 행은 헤더처럼 옅은 배경
                if cell.row == 0:
                    top.font = _header_font
                    top.fill = _table_header_fill
                if cell.row_span > 1 or cell.col_span > 1:
                    ws.merge_cells(
                        start_row=r,
                        start_column=c,
                        end_row=r + cell.row_span - 1,
                        end_column=c + cell.col_span - 1,
                    )
                    for rr in range(r, r + cell.row_span):
                        for cc in range(c, c + cell.col_span):
                            ws.cell(row=rr, column=cc).border = _border
                            if cell.row == 0:
                                ws.cell(row=rr, column=cc).fill = _table_header_fill
            row = table_start + max(table.rows, 1)
            prev_was_table = True

    # 첫 행 freeze (제목 행 고정)
    ws.freeze_panes = "A2"

    wb.save(output_path)
    return output_path
